import flet as ft
import json
import os

def main(page: ft.Page):
    page.title = "Recetario"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.scroll = "adaptive"
    page.theme = ft.Theme(color_scheme_seed="orange")
    page.window_width = 450 # Tamaño ideal para previsualizar móvil

    # --- Carga de datos JSON ---
    def cargar_recetas():
        try:
            # Obtiene la ruta de la carpeta donde está este script (main.py)
            directorio_actual = os.path.dirname(__file__)
            
            # Si tienes el json en una carpeta 'assets', úsala. Si está al lado del script, quita "assets"
            #ruta_json = os.path.join(directorio_actual, "assets", "recetas.json")
            ruta_json = os.path.join(directorio_actual, "recetas.json")
            
            # Si el archivo no está en assets, intenta en la raíz del script
            if not os.path.exists(ruta_json):
                ruta_json = os.path.join(directorio_actual, "recetas.json")

            with open(ruta_json, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data["recetas_total"]["receta"]
        except json.JSONDecodeError as e:
            print(f"❌ ERROR DE SINTAXIS EN JSON: {e}") # Te dirá en qué línea está el error
            return []
            
        except Exception as e:
            print(f"Error detallado: {e}") # Importante para ver el error en la terminal
            return []


    recetas_data = cargar_recetas()

    # --- Componente de Fila de Ingrediente ---
    class FilaIngrediente(ft.Row):
        def __init__(self, nombre, unidad, cantidad_base, porciones_base):
            super().__init__()
            self.nombre = nombre
            self.unidad = unidad
            self.cantidad_base = cantidad_base
            self.porciones_base = porciones_base
            
            self.texto_cantidad = ft.Text(size=14)
            self.controls = [
                ft.Icon(ft.Icons.CHEVRON_RIGHT, size=16, color="orange"),
                self.texto_cantidad
            ]
            self.actualizar(porciones_base)

        def actualizar(self, nuevas_porciones):
            # Regla de tres: (Cantidad Base / Porciones Base) * Nuevas Porciones
            nueva_cantidad = (self.cantidad_base / self.porciones_base) * nuevas_porciones
            # Formateamos para quitar decimales innecesarios (ej: 2.0 -> 2)
            cant_str = f"{nueva_cantidad:g}" 
            self.texto_cantidad.value = f"{cant_str} {self.unidad} de {self.nombre}"

    # --- Componente de Tarjeta de Receta ---
    class TarjetaReceta(ft.Card):
        def __init__(self, receta):
            super().__init__()
            self.receta = receta
            self.elevation = 3
            
            # Campo para editar porciones
            self.input_porciones = ft.TextField(
                value=str(receta['porciones']),
                label="Porciones",
                width=80,
                height=40,
                text_size=14,
                content_padding=10,
                keyboard_type=ft.KeyboardType.NUMBER,
                on_change=self.cambiar_porciones
            )

            # Lista de objetos de ingredientes
            self.objetos_ingredientes = [
                FilaIngrediente(i['nombre'], i['unidad'], i['cantidad'], receta['porciones'])
                for i in receta['ingredientes']
            ]

            self.columna_ingredientes = ft.Column(controls=self.objetos_ingredientes, spacing=5)

            self.content = ft.Container(
                padding=15,
                content=ft.Column([
                    ft.ListTile(
                        leading=ft.Icon(ft.Icons.RESTAURANT, color="orange"),
                        title=ft.Text(receta['nombre'] + ' - Original para ' + str(receta['porciones']), weight="bold", size=18),
                        subtitle=ft.Text(f"Categoría: {receta.get('categoria', 'General')}"),
                    ),
                    ft.Row([
                        ft.Text("Ajustar porciones para esta comida: ", size=12, italic=True),
                        self.input_porciones
                    ], alignment=ft.MainAxisAlignment.START),
                    ft.ExpansionTile(
                        title=ft.Text("Ver Ingredientes y Pasos", color="blue", size=14),
                        initially_expanded=False,
                        controls=[
                            ft.Container(
                                padding=10,
                                content=ft.Column([
                                    ft.Text("Ingredientes ajustados:", weight="bold"),
                                    self.columna_ingredientes,
                                    ft.Divider(),
                                    ft.Text("Preparación:", weight="bold"),
                                    ft.Text(receta.get('preparacion', ''), size=14),
                                ], spacing=10)
                            )
                        ]
                    )
                ])
            )

        def cambiar_porciones(self, e):
            try:
                nuevas = float(self.input_porciones.value)
                if nuevas <= 0: nuevas = 1
            except:
                nuevas = self.receta['porciones'] # Si borra todo, vuelve al base

            for ing in self.objetos_ingredientes:
                ing.actualizar(nuevas)
            self.update()

    # --- Layout Principal ---
    lista_recetas_ui = ft.Column(spacing=15, expand=True)

    def filtrar(e):
        termino = search_bar.value.lower()
        lista_recetas_ui.controls.clear()
        for r in recetas_data:
            if termino in r['nombre'].lower():
                lista_recetas_ui.controls.append(TarjetaReceta(r))
        page.update()

    search_bar = ft.TextField(
        label="¿Qué quieres cocinar hoy?",
        on_change=filtrar,
        prefix_icon=ft.Icons.SEARCH,
        border_radius=20
    )

    # Carga inicial
    for r in recetas_data:
        lista_recetas_ui.controls.append(TarjetaReceta(r))

    page.add(
        ft.Text("Recetario Inteligente", size=28, weight="bold", color="orange-900"),
        search_bar,
        lista_recetas_ui
    )

ft.app(target=main)