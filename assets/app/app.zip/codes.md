flet run --web main.py


flet build web --base-url /NOMBRE_DE_TU_REPOSITORIO/



Para desplegar una aplicación de Flet en GitHub Pages, el proceso es un poco diferente a una web tradicional porque Flet debe compilarse a WebAssembly (WASM).

Aquí tienes la guía paso a paso para que la app de tu mamá esté online hoy mismo.

1. Organiza tu carpeta local
Antes de compilar, asegúrate de que tu estructura sea esta:

Plaintext

mi-recetario/
├── main.py
├── assets/
│   └── recetas.json
Nota: En el código que te pasé, asegúrate de cargar el JSON usando assets/recetas.json para que Flet lo encuentre al empaquetar.

2. Compilar para la Web
Abre la terminal en tu carpeta y ejecuta el comando de compilación:

Bash

flet build web --base-url /recetario.github.io/
flet build web --base-url /NOMBRE_DE_TU_REPOSITORIO/
Importante: Reemplaza NOMBRE_DE_TU_REPOSITORIO por el nombre que le pondrás al proyecto en GitHub (por ejemplo: /recetas-mama/). Las barras / al principio y al final son obligatorias.

Este comando creará una carpeta llamada build/web con muchos archivos (index.html, manifest.json, etc.). Estos son los archivos que subiremos.

3. Crear el Repositorio en GitHub
Ve a tu cuenta de GitHub y crea un nuevo repositorio llamado recetas-mama.

Déjalo como Public (GitHub Pages gratuito solo funciona en repositorios públicos, a menos que tengas cuenta Pro).

No es necesario inicializarlo con README.

4. Subir los archivos (Método Simple)
Aunque puedes usar comandos git, lo más fácil para la primera vez es:

Entra a la carpeta build/web que se generó en tu computadora.

Arrastra todo el contenido de esa carpeta directamente a la ventana de tu navegador en el repositorio de GitHub.

Haz clic en "Commit changes".

5. Configurar GitHub Pages
Una vez que los archivos estén en el repositorio:

Ve a la pestaña Settings (Configuración) de tu repositorio.

En el menú de la izquierda, busca Pages.

En la sección "Build and deployment", asegúrate de que la fuente sea "Deploy from a branch".

En "Branch", selecciona main (o master) y la carpeta /(root).

Haz clic en Save.

6. Ver el resultado
Espera unos 2 o 3 minutos. En la misma pantalla de Pages, aparecerá un recuadro indicando: "Your site is live at..." con un link parecido a este:

https://tu-usuario.github.io/recetas-mama/

Tips para que funcione a la primera:
El archivo JSON: Si al abrir la web no cargan las recetas, revisa que en el archivo main.py la ruta de carga sea relativa: with open("assets/recetas.json", ...) y que el archivo esté dentro de la carpeta assets en tu repositorio.

Icono de la App: Puedes cambiar el archivo favicon.png en la carpeta assets antes de compilar para que tu mamá vea una torta o un icono de cocina en la pestaña del navegador.

Modo App: Dile a tu mamá que, una vez abra el link en su Android, toque los tres puntos de Chrome y elija "Instalar aplicación" o "Agregar a pantalla de inicio". Así tendrá el acceso directo en su celular sin barras de navegación.

¿Quieres que te ayude a crear un pequeño "script de carga" (splash screen) para que la app se vea más profesional mientras cargan las recetas?
